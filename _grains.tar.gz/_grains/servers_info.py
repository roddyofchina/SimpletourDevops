#!/usr/bin/env python
#author:luodi date:2016/01/07
#description: Get server system hardware info
from multiprocessing import cpu_count
from collections import OrderedDict
import glob
import re
import os
import commands
ServerHardInfo={}


def Server_Model():
    Servermodel={}
    Servermodel['Server Model'] = commands.getoutput("""dmidecode | grep 'Product Name' | head -n 1 | awk -F ":" '{print $2}'""")
    return Servermodel
    

def Cpu_count():
    return (cpu_count()) 

def Cpu_Info():
    cpuinfo={}
    with open('/proc/cpuinfo') as f:
        for line in f:
            Cpucount=line.split(':')[0].strip()
            if Cpucount == 'cpu MHz':
                cpuinfo[line.split(':')[0].strip()] = line.split(':')[1].strip()
            if Cpucount == 'cache size':
                cpuinfo[line.split(':')[0].strip()] = line.split(':')[1].strip()
    cpuinfo['L1 cache'] = commands.getoutput("""lscpu | grep L1d |  awk -F "[ :]+" '{print $3}' """)
    cpuinfo['L2 cache'] = commands.getoutput("""lscpu | grep L2 |  awk -F "[ :]+" '{print $3}' """)
    cpuinfo['L3 cache'] = commands.getoutput("""lscpu | grep L3  |  awk -F "[ :]+" '{print $3}' """)
    cpuinfo['cpu processor'] = commands.getoutput("""grep 'processor' /proc/cpuinfo | sort -u | wc -l""")
    cpuinfo['cpu physical '] = commands.getoutput("""cat /proc/cpuinfo| grep "physical id"| sort| uniq| wc -l""")
    cpuinfo['cpu_uuid'] = commands.getoutput("""uuidgen""")
    return cpuinfo


def Mem_Total():
    meminfo=OrderedDict()
    with open('/proc/meminfo') as f:
        for line in f:
            meminfo[line.split(':')[0].strip()] = line.split(':')[1].strip()
    MemTotal=meminfo['MemTotal'].split(' ')[0]
    NewMemTotal=float(MemTotal)/1024**2
    return float('%0.2f' %NewMemTotal)

def Mem_UUID():
    uuid = commands.getoutput("""uuidgen""")
    return uuid


def Swap_Total():
    swapinfo=OrderedDict()
    with open('/proc/meminfo') as f:
        for line in f:
            swapinfo[line.split(':')[0].strip()] = line.split(':')[1].strip()
    SwapTotal=swapinfo['SwapTotal'].split(' ')[0]
    NewSwapTotal=float(SwapTotal)/1024**2
    return float('%0.2f' %NewSwapTotal)

class Disk_Dev:
    def size(self,device):
        nr_sectors = open(device+'/size').read().rstrip('\n')
        sect_size = open(device+'/queue/hw_sector_size').read().rstrip('\n')
        return (float(nr_sectors)*float(sect_size))/(1024.0*1024.0*1024.0)

    def detect_devs(self):
        disk={}
        dev_pattern = ['sd.*','mmcblk*']
        for device in glob.glob('/sys/block/*'):
            for pattern in dev_pattern:
                if re.compile(pattern).match(os.path.basename(device)):
                    disk[os.path.basename(device)]=self.size(device)
        return disk

def ssys():
    disks=Disk_Dev()
    ServerHardInfo['CPU_COUNT']=Cpu_count()
    ServerHardInfo['CPU_Info']=Cpu_Info()
    ServerHardInfo['Mem_Total']=Mem_Total()
    ServerHardInfo['Swap_Total']=Swap_Total()
    ServerHardInfo['Disk_Size']=disks.detect_devs()
    ServerHardInfo['Server_Model']=Server_Model()
    ServerHardInfo['Mem_UUID'] = Mem_UUID()
    return ServerHardInfo

if __name__ == '__main__':
    print Mem_count()
