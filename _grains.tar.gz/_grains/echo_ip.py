import socket

grains_list={}
def echo_ip():
        localIP = socket.gethostbyname(socket.gethostname())
        grains_list['Host_Ip'] = localIP
        grains_list['host_user'] = 'Roddy2015'
        grains_list['job'] = 'it'
        return grains_list
