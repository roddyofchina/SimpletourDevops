import subprocess
import salt.utils
import re
import commands

def DISKS():
    ret = dict()
    fdisk_path = salt.utils.which('fdisk')
    cmd1 = subprocess.Popen(
            '{0} -l'.format(fdisk_path),
            shell=True,
            close_fds=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT).communicate()[0] 
    diskssize = DISKSCOUNT(cmd1)
    ret['disk']=diskssize
    return ret


def DISKSCOUNT(OUT):
    ret = dict()
    groups = re.compile('\r?\n\\d\,').split(OUT)

    for group in groups:
        for line in group.splitlines():
            disk={}
            if ' ' not in line:
                continue
            match = re.match(r'(\w+)\s(\/\w+\/\w+\:)\s(\d+\.\d+\s[A-Z][A-Z])',line)
            if match:
                diskname=match.groups()[1].strip(':')
                disksize=match.groups()[2].strip(' GB')
                patname=diskname.split('/')[2]
                disk['name'] = patname
                disk['size'] = disksize
                with open("/sys/block/%s/queue/rotational" %patname) as f: 
                    for line in f.readlines(): 
                        line=line.strip('\n')
                        if line == '0':
                            disk['type']= 2
                        else:
                            disk['type']= 1
                disk['uuid'] = commands.getoutput("""uuidgen %s""" %diskname)
                ret[patname] = disk
    return ret

    


if __name__ == '__main__':
    print DISKS()
